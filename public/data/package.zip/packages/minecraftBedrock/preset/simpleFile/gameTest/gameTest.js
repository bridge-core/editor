import { register } from 'GameTest'

register('', '', (test) => {})
