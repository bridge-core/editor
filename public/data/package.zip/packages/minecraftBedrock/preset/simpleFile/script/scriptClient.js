let system = client.registerSystem(0, 0)

system.initialize = function () {}
system.update = function () {}
