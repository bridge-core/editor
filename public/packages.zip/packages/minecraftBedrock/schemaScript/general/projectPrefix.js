return {
    type: 'properties',
    generateFile: 'project/projectPrefix.json',
    data: [`${getProjectPrefix()}:`]
}