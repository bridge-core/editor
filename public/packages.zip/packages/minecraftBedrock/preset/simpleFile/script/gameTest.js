import { register } from 'mojang-gametest'

register('', '', (test) => {})
