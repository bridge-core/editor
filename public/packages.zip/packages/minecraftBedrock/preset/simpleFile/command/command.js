export default defineCommand(({ name, template, schema }) => {
	name('')
	schema([])

	template(() => {})
})
