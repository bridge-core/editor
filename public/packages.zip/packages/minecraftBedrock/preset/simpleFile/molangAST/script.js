export default (ast) => {}
