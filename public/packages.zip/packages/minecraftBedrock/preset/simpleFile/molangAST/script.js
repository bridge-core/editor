export default (ast) => {}
